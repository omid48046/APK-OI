# OI Pro Generator
Generated Kotlin Android project ready to be built by the provided workflow.