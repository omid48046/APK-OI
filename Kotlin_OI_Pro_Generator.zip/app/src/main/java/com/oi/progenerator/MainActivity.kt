package com.oi.progenerator
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.oi.progenerator.databinding.ActivityMainBinding
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.generateButton.setOnClickListener {
            val prompt = binding.promptEdit.text.toString().trim()
            if (prompt.isNotEmpty()) generateImage(prompt)
        }
    }
    private fun generateImage(prompt: String) {
        binding.progressBar.visibility = android.view.View.VISIBLE
        lifecycleScope.launch {
            // placeholder: network call should be done here
            val result = withContext(Dispatchers.IO) {
                // call your API (do not embed keys here)
                // return URL or base64 string
                Thread.sleep(1000)
                "https://via.placeholder.com/512.png?text=Generated"
            }
            // show result
            binding.progressBar.visibility = android.view.View.GONE
            // load image with Coil
            coil.load(binding.resultImage, result) {
                crossfade(true)
            }
        }
    }
}
