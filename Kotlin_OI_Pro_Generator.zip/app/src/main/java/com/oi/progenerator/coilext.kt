package com.oi.progenerator
import android.widget.ImageView
import coil.load
fun coilLoad(imageView: ImageView, url: String) { imageView.load(url) }
